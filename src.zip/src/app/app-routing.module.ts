import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'folder/:id',
    loadChildren: () => import('./folder/folder.module').then( m => m.FolderPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./pages/register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'home',
    loadChildren: () => import('./pages/home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'create-program',
    loadChildren: () => import('./pages/create-program/create-program.module').then( m => m.CreateProgramPageModule)
  },
  {
    path: 'view-program',
    loadChildren: () => import('./pages/view-program/view-program.module').then( m => m.ViewProgramPageModule)
  },
  {
    path: 'historyprogram',
    loadChildren: () => import('./pages/historyprogram/historyprogram.module').then( m => m.HistoryprogramPageModule)
  },
  {
    path: 'manageprogram',
    loadChildren: () => import('./pages/manageprogram/manageprogram.module').then( m => m.ManageprogramPageModule)
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
