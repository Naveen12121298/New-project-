import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {

  constructor(public router: Router) { }

  ngOnInit() {
  }


  get_page(data:any){
    if(data == 'new'){
      this.router.navigateByUrl('/create-program');
    }else if(data == 'history'){
      this.router.navigateByUrl('/historyprogram');
    }else if(data == 'view'){
      this.router.navigateByUrl('/view-program');
    }else if(data == 'mange'){
      this.router.navigateByUrl('/manageprogram');
    }
  }

}
