import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreateProgramPageRoutingModule } from './create-program-routing.module';

import { CreateProgramPage } from './create-program.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreateProgramPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [CreateProgramPage]
})
export class CreateProgramPageModule {}
