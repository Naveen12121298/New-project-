import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-program',
  templateUrl: './create-program.page.html',
  styleUrls: ['./create-program.page.scss'],
})
export class CreateProgramPage  {
  registerForm: FormGroup;
  dateTimeValue:any

  profile:any=[{'id':1,"profile":'DSP'},
  {'id':2,"profile":'AC'},
  {'id':3,"profile":'SP'},
  {'id':4,"profile":'INSEPECTOR'},
  {'id':5,"profile":'SI'},
  {'id':6,"profile":'FOP'}
]
  constructor(private formBuilder: FormBuilder,public router: Router) { this.get_profile()
    this.dateTimeValue = new Date().toISOString();
    this.registerForm = this.formBuilder.group({
      firstname: ['', Validators.required],
      profile: ['', Validators.required],
      date1: ['', Validators.required],
    });
  }



  onSubmit(formData: any) {
    if (this.registerForm.valid) {
      console.log('Form Data:', formData);
      // Handle form submission logic here
    } else {
      this.markFormGroupTouched(this.registerForm);
    }
  }

  markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
    });
  }

  openpage(){
    this.router.navigateByUrl('/home');

  }

  get_profile(){
    // this.common.get_profile().subscribe( async res => {
    //   console.log(res,'response');
    // })
  }
}
