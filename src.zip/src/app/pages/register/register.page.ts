import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';



@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage  {

  registerForm: FormGroup;

  profile:any=[{'id':1,"profile":'DSP'},
  {'id':2,"profile":'AC'},
  {'id':3,"profile":'SP'},
  {'id':4,"profile":'INSEPECTOR'},
  {'id':5,"profile":'SI'},
  {'id':6,"profile":'FOP'}
]
  constructor(private formBuilder: FormBuilder,public router: Router) {
    this.get_profile()
  this.registerForm = this.formBuilder.group({
    firstname: ['', Validators.required],
    profile: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    mobile: ['', [Validators.required, Validators.pattern('[0-9]*'), Validators.minLength(10), Validators.maxLength(10)]],
    passwd: ['', Validators.required],
    cpasswd: ['', Validators.required],
  });
}



onSubmit(formData: any) {
  if (this.registerForm.valid) {
    console.log('Form Data:', formData);
    // Handle form submission logic here
  } else {
    this.markFormGroupTouched(this.registerForm);
  }
}

markFormGroupTouched(formGroup: FormGroup) {
  Object.values(formGroup.controls).forEach(control => {
    control.markAsTouched();
  });
}

skip(){
  this.router.navigateByUrl('/login');

}

get_profile(){
  // this.common.get_profile().subscribe( async res => {
  //   console.log(res,'response');
  // })
}

}

