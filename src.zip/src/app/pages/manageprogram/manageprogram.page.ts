import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageprogram',
  templateUrl: './manageprogram.page.html',
  styleUrls: ['./manageprogram.page.scss'],
})
export class ManageprogramPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
