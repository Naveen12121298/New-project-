import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ManageprogramPage } from './manageprogram.page';

describe('ManageprogramPage', () => {
  let component: ManageprogramPage;
  let fixture: ComponentFixture<ManageprogramPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageprogramPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
