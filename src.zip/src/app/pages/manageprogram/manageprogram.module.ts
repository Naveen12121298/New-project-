import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ManageprogramPageRoutingModule } from './manageprogram-routing.module';

import { ManageprogramPage } from './manageprogram.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ManageprogramPageRoutingModule
  ],
  declarations: [ManageprogramPage]
})
export class ManageprogramPageModule {}
