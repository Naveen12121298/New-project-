import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-program',
  templateUrl: './view-program.page.html',
  styleUrls: ['./view-program.page.scss'],
})
export class ViewProgramPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
