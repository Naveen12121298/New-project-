import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ViewProgramPage } from './view-program.page';

describe('ViewProgramPage', () => {
  let component: ViewProgramPage;
  let fixture: ComponentFixture<ViewProgramPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewProgramPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
