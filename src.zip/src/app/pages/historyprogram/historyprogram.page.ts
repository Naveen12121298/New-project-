import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-historyprogram',
  templateUrl: './historyprogram.page.html',
  styleUrls: ['./historyprogram.page.scss'],
})
export class HistoryprogramPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
