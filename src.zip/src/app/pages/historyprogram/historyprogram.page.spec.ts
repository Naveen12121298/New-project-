import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HistoryprogramPage } from './historyprogram.page';

describe('HistoryprogramPage', () => {
  let component: HistoryprogramPage;
  let fixture: ComponentFixture<HistoryprogramPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(HistoryprogramPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
